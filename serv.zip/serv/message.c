#include <stdio.h> // in main.c
#include <stdlib.h> // in main.c
#include <string.h> // in main.c
#include <unistd.h> // in main.c
#include <sys/socket.h> // in main.c
#include <netinet/in.h> // in main.c
#include <sys/select.h>

typedef struct s_cli {
    int id;
    char msg[1000000];
} t_cli;

t_cli cli[1024];
char readbuff[1000000], writebuff[1000000];
int max_fd = 0, next_id = 0;
fd_set read_fds, write_fds, active_fds;

void error(char *str) {
    write(2, str, strlen(str));
    exit(1);
}

void sendMsg(int sfd) {
    for (int fd = 0; fd <= max_fd; fd++)
        if (FD_ISSET(fd, &write_fds) && fd != sfd)
            send(fd, writebuff, strlen(writebuff), 0);
}

int f(int sockfd)
{
	int fd = accept(sockfd, 0, 0);
	if (fd < 0) return 1;
	if (fd > max_fd) max_fd = fd;
	cli[fd].id = next_id++;
	bzero(cli[fd].msg, sizeof(cli[fd].msg));
	FD_SET(fd, &active_fds);
	sprintf(writebuff, "server: client %d just arrived\n", cli[fd].id);
	sendMsg(fd);
	return 0;
}

void s(int fd)
{
	if (!FD_ISSET(fd, &read_fds)) return;
	int num = recv(fd, readbuff, sizeof(readbuff) - 1, 0);
	if (num <= 0) {
		sprintf(writebuff, "server: client %d just left\n", cli[fd].id);
		sendMsg(fd);
		FD_CLR(fd, &active_fds);
		close(fd);
	} else {
		readbuff[num] = '\0';
		for (int i = 0, j = strlen(cli[fd].msg); i < num && (size_t)j < sizeof(cli[fd].msg) - 1; i++, j++) {
			cli[fd].msg[j] = readbuff[i];
			if (cli[fd].msg[j] == '\n') {
				cli[fd].msg[j] = '\0';
				sprintf(writebuff, "client %d: %s\n", cli[fd].id, cli[fd].msg);
				sendMsg(fd);
				bzero(cli[fd].msg, sizeof(cli[fd].msg));
				j = -1;
			}
		}
	}
}

int main(int ac, char **av) {
    if (ac != 2)
		error("Wrong number of arguments\n");
    int sockfd = socket(AF_INET, SOCK_STREAM, 0); // in main.c
    if (sockfd == -1) // in main.c
        error("Fatal error\n");  // replace what in main with "Fatal error\n" message
    max_fd = sockfd;
    FD_ZERO(&active_fds);
    FD_SET(sockfd, &active_fds);
    struct sockaddr_in servaddr; // in main.c
    bzero(&servaddr, sizeof(servaddr)); // in main.c
    servaddr.sin_family = AF_INET; // in main.c
    servaddr.sin_addr.s_addr = htonl(2130706433); // in main.c
    servaddr.sin_port = htons(atoi(av[1])); // in main.c
    if (bind(sockfd, (const struct sockaddr *)&servaddr, sizeof(servaddr)) != 0) // in main.c
        error("Fatal error\n"); // replace what in main with "Fatal error\n" message
    if (listen(sockfd, 10) != 0) // in main.c
        error("Fatal error\n"); // replace what in main with "Fatal error\n" message
    while (1) {
        read_fds = write_fds = active_fds;
        if (select(max_fd + 1, &read_fds, &write_fds, 0, 0) < 0) continue;
        for (int fd = 0; fd <= max_fd; fd++) {
            if (FD_ISSET(fd, &read_fds) && fd == sockfd) {
				if (f(sockfd)) continue;
			} else
				s(fd);
        }
    }
}