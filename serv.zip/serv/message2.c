#include <errno.h>
#include <string.h>
#include <unistd.h>
#include <netdb.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <stdio.h>
#include <stdlib.h>

typedef struct s_client {
  int id;
  char *msg;
} t_client;

t_client clients[1024];


int extract_message(char **buf, char **msg)
{
	char	*newbuf;
	int	i;

	*msg = 0;
	if (*buf == 0)
		return (0);
	i = 0;
	while ((*buf)[i])
	{
		if ((*buf)[i] == '\n')
		{
			newbuf = calloc(1, sizeof(*newbuf) * (strlen(*buf + i + 1) + 1));
			if (newbuf == 0)
				return (-1);
			strcpy(newbuf, *buf + i + 1);
			*msg = *buf;
			(*msg)[i + 1] = 0;
			*buf = newbuf;
			return (1);
		}
		i++;
	}
	return (0);
}

char *str_join(char *buf, char *add)
{
	char	*newbuf;
	int		len;

	if (buf == 0)
		len = 0;
	else
		len = strlen(buf);
	newbuf = malloc(sizeof(*newbuf) * (len + strlen(add) + 1));
	if (newbuf == 0)
		return (0);
	newbuf[0] = 0;
	if (buf != 0)
		strcat(newbuf, buf);
	free(buf);
	strcat(newbuf, add);
	return (newbuf);
}

void exit_werror(char *s, int code) {
  if (s)
    write(2, s, strlen(s));
  exit(code);
}

void broadcast(int exceptfd, int count, fd_set *fdw, char *wbuff) {
  for(int i = 0; i <= count; i++) {
    if (exceptfd != i && FD_ISSET(i, fdw))
      send(i, wbuff, strlen(wbuff), 0);
  }
}
void s() {
  system("leaks test");
}
int main(int ac, char **av) {
  atexit(s);
  if (ac != 2)
    exit_werror("Fatal Error\n", 1);
  int buffer_size = 262144;
  char wbuff[buffer_size];
  char rbuff[buffer_size];
	int sockfd, connfd, maxfd, cid;
  socklen_t len;
	struct sockaddr_in servaddr, cli; 
  fd_set fdr, fdw, fda;
  cid = 0;
	// socket create and verification 
	sockfd = socket(AF_INET, SOCK_STREAM, 0); 
	if (sockfd == -1)
    exit_werror("Fatal Error\n", 1);
	maxfd = sockfd;
  FD_ZERO(&fda);
  FD_SET(sockfd, &fda);
	bzero(&servaddr, sizeof(servaddr)); 
	// assign IP, PORT 
	servaddr.sin_family = AF_INET; 
	servaddr.sin_addr.s_addr = htonl(2130706433); //127.0.0.1
	servaddr.sin_port = htons(atoi(av[1])); 
  
	// Binding newly created socket to given IP and verification 
	if ((bind(sockfd, (const struct sockaddr *)&servaddr, sizeof(servaddr))) != 0)
    exit_werror("Fatal Error\n", 1);
	
	if (listen(sockfd, 10) != 0)
    exit_werror("Fatal Error\n", 1);
	
  FD_ZERO(&fdr);
  FD_ZERO(&fdw);

  len = sizeof(cli);
  while (1) {
    fdr = fdw = fda;
    if (select(maxfd + 1, &fdr, &fdw, 0, 0) < 0)
      continue ;
    for (int i = 0; i <= maxfd; i++) {
      if (!FD_ISSET(i, &fdr))
        continue ;
      if (i == sockfd) {
        connfd = accept(sockfd, (struct sockaddr *)&cli, &len);
        if (connfd < 0)
          continue ;
        if (connfd > maxfd)
          maxfd = connfd;
        clients[connfd].id = cid++;
        FD_SET(connfd, &fda);
        clients[connfd].msg = NULL;
        bzero(wbuff, buffer_size);
        sprintf(wbuff, "server: client %d just arrived\n", clients[connfd].id);
        broadcast(connfd, maxfd, &fdw, wbuff);
      } else {
        bzero(rbuff, buffer_size);
        int rbytes = recv(i, rbuff, buffer_size, 0);
        if (rbytes <= 0) {
          // left
          bzero(wbuff, buffer_size);
          sprintf(wbuff, "server: client %d just left\n", clients[i].id);
          broadcast(i, maxfd, &fdw, wbuff);
          close(i);
          FD_CLR(i, &fda);
          free(clients[i].msg);
          clients[i].msg = NULL;
        } else {
          // join and extract message
          
          rbuff[rbytes] = 0;
          clients[i].msg = str_join(clients[i].msg, rbuff);
          char *line;

          while (extract_message(&clients[i].msg, &line)) {
            bzero(wbuff, buffer_size);
            sprintf(wbuff, "client %d: %s", clients[i].id, line);
            broadcast(i, maxfd, &fdw, wbuff);
            free(line);
            line = NULL;
          }
        }
      }
      
    }
  }

}