#include <stdio.h> 
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <sys/select.h>

int extract_message(char **buf, char **msg)
{
	char	*newbuf;
	int	i;

	*msg = 0;
	if (*buf == 0)
		return (0);
	i = 0;
	while ((*buf)[i])
	{
		if ((*buf)[i] == '\n')
		{
			newbuf = calloc(1, sizeof(*newbuf) * (strlen(*buf + i + 1) + 1));
			if (newbuf == 0)
				return (-1);
			strcpy(newbuf, *buf + i + 1);
			*msg = *buf;
			(*msg)[i + 1] = 0;
			*buf = newbuf;
			return (1);
		}
		i++;
	}
	return (0);
}

char *str_join(char *buf, char *add)
{
	char	*newbuf;
	int		len;

	if (buf == 0)
		len = 0;
	else
		len = strlen(buf);
	newbuf = malloc(sizeof(*newbuf) * (len + strlen(add) + 1));
	if (newbuf == 0)
		return (0);
	newbuf[0] = 0;
	if (buf != 0)
		strcat(newbuf, buf);
	free(buf);
	strcat(newbuf, add);
	return (newbuf);
}

typedef struct s_client
{
    int id;
    char *msg;
} t_client;

t_client clients[1024];
char buffRead[1000000], buffWrite[1000000];
int max_fd = 0, next_id = 0;
fd_set active_fds, read_fds, write_fds;

void exitError(char *str)
{
    write(2, str, strlen(str));
    exit(1);
}

void sendMsg(int sender_fd)
{
    for (int fd = 0; fd <= max_fd; fd++)
        if (FD_ISSET(fd, &write_fds) && fd != sender_fd)
            send(fd, buffWrite, strlen(buffWrite), 0);
}

int main(int ac, char **av)
{
    if (ac != 2)
        exitError("Wrong number of arguments\n");
    int sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd == -1)
        exitError("Fatal error\n");
    max_fd = sockfd;
    FD_ZERO(&active_fds);
    FD_SET(sockfd, &active_fds);
    struct sockaddr_in sadd;
    memset(&sadd, 0, sizeof(sadd));
    sadd.sin_family = AF_INET;
    sadd.sin_addr.s_addr = htonl(2130706433); // 127.0.0.1
    sadd.sin_port = htons(atoi(av[1]));
    if (bind(sockfd, (const struct sockaddr *)&sadd, sizeof(sadd)) != 0)
        exitError("Fatal error\n");
    if (listen(sockfd, 10) != 0)
        exitError("Fatal error\n");
    while (1)
    {
        read_fds = write_fds = active_fds;
        if (select(max_fd + 1, &read_fds, &write_fds, NULL, NULL) < 0)
            continue;
        for (int fd = 0; fd <= max_fd; fd++)
        {
            if (FD_ISSET(fd, &read_fds) && fd == sockfd)
            {
                int cl_sock = accept(sockfd, NULL, NULL);
                if (cl_sock < 0)
                    continue;
                if (cl_sock > max_fd)
                    max_fd = cl_sock;
                clients[cl_sock].id = next_id++;
                clients[cl_sock].msg = NULL;
                FD_SET(cl_sock, &active_fds);
                sprintf(buffWrite, "server: client %d just arrived\n", clients[cl_sock].id);
                sendMsg(cl_sock);
                break;
            }
            else if (FD_ISSET(fd, &read_fds))
            {
                int read_bytes = recv(fd, buffRead, sizeof(buffRead) - 1, 0);
                if (read_bytes <= 0)
                {
                    sprintf(buffWrite, "server: client %d just left\n", clients[fd].id);
                    sendMsg(fd);
                    FD_CLR(fd, &active_fds);
                    free(clients[fd].msg);
                    close(fd);
                    break;
                }
                else
                {
                    buffRead[read_bytes] = '\0';
                    buffRead[read_bytes] = 0;
                    clients[fd].msg = str_join(clients[fd].msg, buffRead);
                    char *line;

                    while (extract_message(&clients[fd].msg, &line)) 
                    {
                        bzero(buffWrite, sizeof(buffWrite));
                        sprintf(buffWrite, "client %d: %s", clients[fd].id, line);
                        sendMsg(fd);
                        free(line);
                        line = NULL;
                    }
                }
            }
        }
    }
}